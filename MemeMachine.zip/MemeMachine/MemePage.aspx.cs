﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        //var imageUrl = "E:\\Enterprise\\MemeMachine\\Images\\MemeMachine Icon.jpg";

        //myImage.ImageUrl = "E:\\Enterprise\\MemeMachine\\Images\\Earth.jpg";

        //bool temp1S, temp2S, temp3S, temp4S, temp5S;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        Random random1 = new Random();
        int numTEMP = random1.Next(0, 17);
        int numSRC = random1.Next(0, 20);

        tempImg.ImageUrl = "~/Images/temp" + numTEMP.ToString() + ".jpg";
        srcImg.ImageUrl = "~/Images/src" + numSRC.ToString() + ".jpg";



        switch (numTEMP) {
            case 0:
                boilerPlate();
                srcImg.Style.Add("TOP", "200px");
                srcImg.Style.Add("LEFT", "575px");
                srcImg.Style.Add("WIDTH", "500px");
                srcImg.Style.Add("HEIGHT", "420px");
                srcImg.Style.Add("z-index", "-1");
                
                tempImg.Style.Add("WIDTH", "300px");
                tempImg.Style.Add("HEIGHT", "50px");
                tempImg.Style.Add("TOP", "550px");
                tempImg.Style.Add("LEFT", "775px");
                break;

            case 1:
                whenYouMeme();
                break;

            case 2:
                whenYouMeme();
                srcImg.Style.Add("TOP", "310px");
                break;

            case 3:
                boilerPlate();
                srcImg.Style.Add("TOP", "330px");
                srcImg.Style.Add("LEFT", "690px");
                srcImg.Style.Add("WIDTH", "320px");
                srcImg.Style.Add("HEIGHT", "340px");

                tempImg.Style.Add("WIDTH", "380px");
                tempImg.Style.Add("HEIGHT", "508px");
                tempImg.Style.Add("TOP", "180px");
                tempImg.Style.Add("LEFT", "653px");

                break;

            case 4:
                boilerPlate();
                srcImg.Style.Add("TOP", "465px");
                srcImg.Style.Add("LEFT", "683px");
                srcImg.Style.Add("WIDTH", "200px");
                srcImg.Style.Add("HEIGHT", "180px");

                tempImg.Style.Add("WIDTH", "380px");
                tempImg.Style.Add("HEIGHT", "475px");
                tempImg.Style.Add("TOP", "180px");
                tempImg.Style.Add("LEFT", "653px");

                break;

            case 5:
                boilerPlate();
                srcImg.Style.Add("TOP", "240px");
                srcImg.Style.Add("LEFT", "853px");
                srcImg.Style.Add("WIDTH", "200px");
                srcImg.Style.Add("HEIGHT", "220px");
                
                tempImg.Style.Add("WIDTH", "480px");
                tempImg.Style.Add("HEIGHT", "424px");
                tempImg.Style.Add("TOP", "180px");
                tempImg.Style.Add("LEFT", "600px");

                break;

            case 6:
                boilerPlate();
                srcImg.Style.Add("TOP", "345px");
                srcImg.Style.Add("LEFT", "700px");
                srcImg.Style.Add("WIDTH", "240px");
                srcImg.Style.Add("HEIGHT", "215px");
                
                tempImg.Style.Add("WIDTH", "550px");
                tempImg.Style.Add("HEIGHT", "400px");
                tempImg.Style.Add("TOP", "180px");
                tempImg.Style.Add("LEFT", "560px");

                break;

            case 7:
                boilerPlate();
                srcImg.Style.Add("TOP", "450px");
                srcImg.Style.Add("LEFT", "36%");
                srcImg.Style.Add("WIDTH", "248px");
                srcImg.Style.Add("HEIGHT", "230px");

                tempImg.Style.Add("WIDTH", "480px");
                tempImg.Style.Add("HEIGHT", "482px");
                tempImg.Style.Add("TOP", "200px");
                tempImg.Style.Add("LEFT", "36%");

                break;

            case 8:
                whenYouMeme();
                srcImg.Style.Add("TOP", "360px");
                srcImg.Style.Add("LEFT", "655px");
                srcImg.Style.Add("WIDTH", "350px");
                srcImg.Style.Add("HEIGHT", "310px");

                break;


            case 9:
                boilerPlate();
                srcImg.Style.Add("TOP", "345px");
                srcImg.Style.Add("LEFT", "800px");
                srcImg.Style.Add("WIDTH", "200px");
                srcImg.Style.Add("HEIGHT", "175px");

                tempImg.Style.Add("WIDTH", "550px");
                tempImg.Style.Add("HEIGHT", "400px");
                tempImg.Style.Add("TOP", "180px");
                tempImg.Style.Add("LEFT", "560px");

                break;

            case 10:
                boilerPlate();
                srcImg.Style.Add("TOP", "450px");
                srcImg.Style.Add("LEFT", "36%");
                srcImg.Style.Add("WIDTH", "248px");
                srcImg.Style.Add("HEIGHT", "230px");

                tempImg.Style.Add("WIDTH", "480px");
                tempImg.Style.Add("HEIGHT", "482px");
                tempImg.Style.Add("TOP", "200px");
                tempImg.Style.Add("LEFT", "36%");

                break;

            case 11:
                boilerPlate();
                srcImg.Style.Add("TOP", "240px");
                srcImg.Style.Add("LEFT", "675px");
                srcImg.Style.Add("WIDTH", "100px");
                srcImg.Style.Add("HEIGHT", "85px");

                tempImg.Style.Add("WIDTH", "580px");
                tempImg.Style.Add("HEIGHT", "420px");
                tempImg.Style.Add("TOP", "180px");
                tempImg.Style.Add("LEFT", "540px");

                break;

            case 12:
                boilerPlate();
                srcImg.Style.Add("TOP", "425px");
                srcImg.Style.Add("LEFT", "968px");
                srcImg.Style.Add("WIDTH", "165px");
                srcImg.Style.Add("HEIGHT", "150px");

                tempImg.Style.Add("WIDTH", "600px");
                tempImg.Style.Add("HEIGHT", "430px");
                tempImg.Style.Add("TOP", "180px");
                tempImg.Style.Add("LEFT", "535px");

                break;

            case 13:
                boilerPlate();
                srcImg.Style.Add("TOP", "340px");
                srcImg.Style.Add("LEFT", "793.5px");
                srcImg.Style.Add("WIDTH", "100px");
                srcImg.Style.Add("HEIGHT", "100px");

                tempImg.Style.Add("WIDTH", "550px");
                tempImg.Style.Add("HEIGHT", "400px");
                tempImg.Style.Add("TOP", "180px");
                tempImg.Style.Add("LEFT", "560px");

                break;

            case 14:
                whenYouMeme();
                srcImg.Style.Add("TOP", "290px");

                break;

            case 15:
                whenYouMeme();
                srcImg.Style.Add("TOP", "195px");
                srcImg.Style.Add("LEFT", "635px");
                srcImg.Style.Add("WIDTH", "385px");
                srcImg.Style.Add("HEIGHT", "330px");

                break;

            case 16:
                whenYouMeme();
                srcImg.Style.Add("WIDTH", "415px");
                srcImg.Style.Add("HEIGHT", "345px");
                srcImg.Style.Add("TOP", "320px");
                srcImg.Style.Add("LEFT", "615px");
                break;


        }



    }

    protected void boilerPlate()
    {
        srcImg.Style.Add("position", "absolute");
        srcImg.Style.Add("TOP", "0px");
        srcImg.Style.Add("LEFT", "0px");
        srcImg.Style.Add("WIDTH", "0px");
        srcImg.Style.Add("HEIGHT", "0px");
        srcImg.Style.Add("z-index", "+1");

        tempImg.Style.Add("position", "absolute");
        tempImg.Style.Add("WIDTH", "0px");
        tempImg.Style.Add("HEIGHT", "0px");
        tempImg.Style.Add("TOP", "0px");
        tempImg.Style.Add("LEFT", "0px");
    }




    protected void whenYouMeme() {
        boilerPlate();
        srcImg.Style.Add("TOP", "300px");
        srcImg.Style.Add("LEFT", "615px");
        srcImg.Style.Add("WIDTH", "430px");
        srcImg.Style.Add("HEIGHT", "365px");
        
        tempImg.Style.Add("WIDTH", "500px");
        tempImg.Style.Add("HEIGHT", "500px");
        tempImg.Style.Add("TOP", "180px");
        tempImg.Style.Add("LEFT", "580px");
    }
}