﻿using System;
using System.Data;
using System.Web.Security;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class SignUp : System.Web.UI.Page
{

    SqlCommand cmd = new SqlCommand();
    SqlCommand cmdUserChecker = new SqlCommand();
    SqlCommand cmdEmailChecker = new SqlCommand();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        //Opens connection to the Database
        //con.ConnectionString = "Data source =stusql;initial catalog=MemeMachine;integrated Security=true";
        //con.Open();
    }

    protected void Button3_Click(object sender, EventArgs e)
    {

        /*
         * TODO:
         *  BLANK SPACE AT THE BEGINNING
         *  
         */

        cmdEmailChecker.CommandText = "SELECT * FROM USERS WHERE EMAIL = '" + emailBox.Text + "'";
        cmdEmailChecker.Connection = con;
        sda.SelectCommand = cmdEmailChecker;
        sda.Fill(ds, "USERS");

        if (ds.Tables[0].Rows.Count == 0)
        {
            cmdUserChecker.CommandText = "SELECT * FROM USERS WHERE USERNAME = '" + userName.Text + "'";
            cmdUserChecker.Connection = con;
            sda.SelectCommand = cmdUserChecker;
            sda.Fill(ds, "USERS");

            if (ds.Tables[0].Rows.Count == 0)
            {

                if (userName.Text != "" && emailBox.Text != "" && passWord.Text != "" && confirmPass.Text != "")
                {

                    if (passWord.Text.Equals(confirmPass.Text))
                    {
                        cmd.CommandText = "INSERT INTO USERS VALUES('" + userName.Text + "', 0, '" + emailBox.Text + "', '" + passWord.Text + "');";
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        sda.Fill(ds, "USERS");
                        Label1.Text = "";
                        Response.Redirect("SignIn.aspx?Scr=");
                    }else
                        Label1.Text = "Passwords do not match";
                }else
                    Label1.Text = "Please fill in all fields";

            }else
                Label1.Text = "Username is taken";
        } else
            Label1.Text = "Email is taken";
    }
}