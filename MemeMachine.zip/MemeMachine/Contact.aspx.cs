﻿using System;
using System.Net.Mail;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    private static void SendMailMessage(string from, string to, string cc, string bcc, string subject, string body, bool IsHtml)
    {
        MailMessage tMailMessage = new MailMessage();
        tMailMessage.From = new MailAddress(from);

        tMailMessage.To.Add(new MailAddress(to));

        if (cc != null && cc != "")
            tMailMessage.CC.Add(new MailAddress(cc));

        if (bcc != null && bcc != "")
            tMailMessage.Bcc.Add(new MailAddress(bcc));

        tMailMessage.Subject = subject;

        tMailMessage.Body = body;

        tMailMessage.IsBodyHtml = IsHtml;

        tMailMessage.Priority = MailPriority.Normal;

        tMailMessage.SubjectEncoding = System.Text.Encoding.UTF8;

        tMailMessage.BodyEncoding = System.Text.Encoding.UTF8;
        
        SmtpClient tsmtpClient = new SmtpClient("smtp.gmail.com", 587);

        tsmtpClient.EnableSsl = true;

        tsmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;

        tsmtpClient.UseDefaultCredentials = false;

        tsmtpClient.Credentials = new System.Net.NetworkCredential("khf1@students.ptcollege.edu", "*********");
        tsmtpClient.Send(tMailMessage);

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string _from = "khf1@students.ptcollege.edu";
        string _to = txtTo.Text.Trim();
        string _cc = txtCC.Text.Trim();
        string _bcc = txtBCC.Text.Trim();
        string _subject = txtSubject.Text.Trim();
        string _body = txtBody.Text.Trim();
    }
}