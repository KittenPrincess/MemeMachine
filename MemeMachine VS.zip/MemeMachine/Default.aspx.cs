﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        //var imageUrl = "E:\\Enterprise\\MemeMachine\\Images\\MemeMachine Icon.jpg";

        //myImage.ImageUrl = "E:\\Enterprise\\MemeMachine\\Images\\Earth.jpg";

        //bool temp1S, temp2S, temp3S, temp4S, temp5S;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        Random random1 = new Random();
        int numTEMP = random1.Next(0, 8);
        int numSRC = random1.Next(0, 15);

        tempImg.ImageUrl = "~/Images/temp" + numTEMP.ToString() + ".jpg";
        srcImg.ImageUrl = "~/Images/src" + numSRC.ToString() + ".jpg";



        switch (numTEMP) {
            case 0:
                boilerPlate();
                srcImg.Style.Add("WIDTH", "430px");
                srcImg.Style.Add("HEIGHT", "365px");
                srcImg.Style.Add("z-index", "-1");
                
                tempImg.Style.Add("WIDTH", "300px");
                tempImg.Style.Add("HEIGHT", "50px");
                tempImg.Style.Add("TOP", "300px");
                tempImg.Style.Add("LEFT", "150px");
                break;

            case 1:
                whenYouMeme();
                break;

            case 2:
                whenYouMeme();
                srcImg.Style.Add("TOP", "140px");
                srcImg.Style.Add("LEFT", "30px");
                break;

            case 3:
                boilerPlate();
                srcImg.Style.Add("TOP", "150px");
                srcImg.Style.Add("LEFT", "33px");
                srcImg.Style.Add("WIDTH", "320px");
                srcImg.Style.Add("HEIGHT", "340px");

                tempImg.Style.Add("WIDTH", "380px");
                tempImg.Style.Add("HEIGHT", "508px");

                break;

            case 4:
                boilerPlate();
                srcImg.Style.Add("TOP", "285px");
                srcImg.Style.Add("LEFT", "30px");
                srcImg.Style.Add("WIDTH", "200px");
                srcImg.Style.Add("HEIGHT", "180px");
                srcImg.Style.Add("z-index", "+1");

                tempImg.Style.Add("WIDTH", "380px");
                tempImg.Style.Add("HEIGHT", "475px");

                break;

            case 5:
                boilerPlate();
                srcImg.Style.Add("TOP", "60px");
                srcImg.Style.Add("LEFT", "200px");
                srcImg.Style.Add("WIDTH", "180px");
                srcImg.Style.Add("HEIGHT", "220px");
                
                tempImg.Style.Add("WIDTH", "380px");
                tempImg.Style.Add("HEIGHT", "336px");

                break;

            case 6:
                boilerPlate();
                srcImg.Style.Add("TOP", "160px");
                srcImg.Style.Add("LEFT", "100px");
                srcImg.Style.Add("WIDTH", "200px");
                srcImg.Style.Add("HEIGHT", "180px");
                
                tempImg.Style.Add("WIDTH", "480px");
                tempImg.Style.Add("HEIGHT", "356px");

                break;

            case 7:
                boilerPlate();
                srcImg.Style.Add("TOP", "260px");
                srcImg.Style.Add("LEFT", "0.5px");
                srcImg.Style.Add("WIDTH", "248px");
                srcImg.Style.Add("HEIGHT", "230px");

                tempImg.Style.Add("WIDTH", "480px");
                tempImg.Style.Add("HEIGHT", "482px");

                break;

        }
        


    }

    protected void boilerPlate()
    {
        srcImg.Style.Add("position", "absolute");
        srcImg.Style.Add("TOP", "0px");
        srcImg.Style.Add("LEFT", "0px");
        srcImg.Style.Add("WIDTH", "0px");
        srcImg.Style.Add("HEIGHT", "0px");
        srcImg.Style.Add("z-index", "+1");

        tempImg.Style.Add("position", "absolute");
        tempImg.Style.Add("WIDTH", "0px");
        tempImg.Style.Add("HEIGHT", "0px");
        tempImg.Style.Add("TOP", "0px");
        tempImg.Style.Add("LEFT", "0px");
    }




    protected void whenYouMeme() {
        boilerPlate();
        srcImg.Style.Add("TOP", "120px");
        srcImg.Style.Add("LEFT", "23px");
        srcImg.Style.Add("WIDTH", "430px");
        srcImg.Style.Add("HEIGHT", "365px");
        
        tempImg.Style.Add("WIDTH", "500px");
        tempImg.Style.Add("HEIGHT", "500px");
    }
}